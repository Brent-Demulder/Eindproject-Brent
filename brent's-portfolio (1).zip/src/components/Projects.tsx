import { motion } from "motion/react";
import { ArrowUpRight, TrendingUp, ShieldCheck, Globe, Cpu } from "lucide-react";

export default function Projects() {
  return (
    <section id="projects" className="py-32 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-8 text-center md:text-left">
          <div>
            <span className="text-brand-accent font-bold uppercase tracking-widest text-sm mb-4 block">Portfolio</span>
            <h2 className="text-5xl md:text-7xl font-display font-bold tracking-tighter leading-tight">
              LATEST <br /> <span className="text-zinc-600 italic">CREATIONS.</span>
            </h2>
          </div>
          <p className="text-brand-secondary max-w-sm text-balance text-lg">
            A diverse range of projects from digital architectures to minimalist experiences.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 md:grid-rows-2 gap-4 lg:gap-6">
          {/* Main Large Card - JUNE20 */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="md:col-span-8 md:row-span-2 group relative overflow-hidden rounded-[2.5rem] bg-gradient-to-br from-brand-accent/20 to-brand-accent-secondary/20 border border-white/10 p-10 shadow-2xl min-h-[500px]"
          >
            <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-brand-accent/10 blur-[120px] -z-10 group-hover:bg-brand-accent/20 transition-colors" />
            
            <div className="h-full flex flex-col justify-between relative z-10">
              <div className="flex justify-between items-start">
                <div>
                  <span className="text-brand-accent font-bold uppercase tracking-widest text-xs mb-4 block">Case Study 01</span>
                  <h3 className="text-4xl md:text-6xl font-display font-bold mb-6 tracking-tighter leading-[0.9]">A day in the life <br/> of <span className="italic">JUNE20</span></h3>
                  <p className="text-brand-secondary text-lg max-w-sm">An immersive documentary exploring the pulse of creative culture and agency life.</p>
                </div>
                <div className="w-16 h-16 rounded-full glass border-white/20 flex items-center justify-center group-hover:bg-brand-accent group-hover:text-white transition-all duration-500">
                  <ArrowUpRight size={28} />
                </div>
              </div>

              {/* Visual Element */}
              <div className="mt-12 glass rounded-[2rem] h-64 shadow-strong overflow-hidden relative">
                <img 
                  src="https://images.unsplash.com/photo-1614850523296-d8c1af93d400?auto=format&fit=crop&q=80&w=1200" 
                  className="w-full h-full object-cover grayscale opacity-40 group-hover:grayscale-0 group-hover:opacity-100 transition-all duration-1000"
                  alt="JUNE20 Project"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex flex-col justify-end p-8">
                   <div className="flex gap-4">
                      <div className="px-3 py-1 rounded-full bg-white/10 backdrop-blur-md text-[10px] font-bold uppercase tracking-wider">Production</div>
                      <div className="px-3 py-1 rounded-full bg-white/10 backdrop-blur-md text-[10px] font-bold uppercase tracking-wider">Culture</div>
                   </div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Feature Card 1 - Case Project */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="md:col-span-4 group relative overflow-hidden rounded-[2.5rem] bg-zinc-900 border border-white/5 p-8 flex flex-col justify-between hover:border-brand-accent/50 transition-all duration-500"
          >
            <div className="absolute inset-0 bg-brand-accent/5 opacity-0 group-hover:opacity-100 transition-opacity" />
            <div className="w-12 h-12 rounded-2xl bg-brand-accent/10 flex items-center justify-center mb-6">
               <ShieldCheck className="text-brand-accent" />
            </div>
            <div>
              <span className="text-brand-accent font-bold uppercase tracking-widest text-[10px] mb-2 block">Case Study 02</span>
              <h4 className="text-3xl font-display font-bold mb-3 tracking-tight">Case <br/> Project</h4>
              <p className="text-brand-secondary text-sm leading-relaxed">A deep dive into functional structural design and user behavior analytics.</p>
            </div>
          </motion.div>

          {/* Feature Card 2 - Poster Designs */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="md:col-span-4 group relative overflow-hidden rounded-[2.5rem] bg-zinc-900 border border-white/5 p-8 flex flex-col justify-between hover:border-brand-accent-secondary/50 transition-all duration-500"
          >
             <div className="absolute inset-0 bg-brand-accent-secondary/5 opacity-0 group-hover:opacity-100 transition-opacity" />
             <div className="w-12 h-12 rounded-2xl bg-brand-accent-secondary/10 flex items-center justify-center mb-6">
               <Cpu className="text-brand-accent-secondary" />
            </div>
            <div>
              <span className="text-brand-accent-secondary font-bold uppercase tracking-widest text-[10px] mb-2 block">Case Study 03</span>
              <h4 className="text-3xl font-display font-bold mb-3 tracking-tight">Poster <br/> Designs</h4>
              <p className="text-brand-secondary text-sm leading-relaxed">Experimental typography and Swiss-style layout compositions for modern branding.</p>
            </div>
          </motion.div>
        </div>


      </div>
    </section>
  );
}

