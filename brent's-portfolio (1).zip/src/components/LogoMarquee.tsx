import { motion } from "motion/react";

const logos = [
  "ADIDAS", "NIKE", "APPLE", "GOOGLE", "TESLA", "SPACE X", "META", "AMAZON", "NETFLIX", "SPOTIFY"
];

export default function LogoMarquee() {
  return (
    <section className="py-20 border-y border-white/5 bg-black overflow-hidden select-none">
      <div className="flex whitespace-nowrap">
        <motion.div
          animate={{ x: [0, -1000] }}
          transition={{
            x: {
              repeat: Infinity,
              repeatType: "loop",
              duration: 20,
              ease: "linear",
            },
          }}
          className="flex gap-20 items-center pr-20"
        >
          {Array.from({ length: 2 }).map((_, outerIdx) => (
            <div key={outerIdx} className="flex gap-20 items-center">
              {logos.map((logo, idx) => (
                <span 
                  key={idx} 
                  className="text-4xl md:text-6xl font-display font-bold text-white/10 hover:text-brand-accent transition-colors duration-500 cursor-default"
                >
                  {logo}
                </span>
              ))}
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
