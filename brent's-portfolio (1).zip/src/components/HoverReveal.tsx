import { motion, useMotionValue, useSpring } from "motion/react";
import { useState } from "react";

const reveals = [
  {
    title: "DIGITAL ARCHITECTURE",
    image: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&q=80&w=800",
  },
  {
    title: "VIRTUAL EXPERIENCES",
    image: "https://images.unsplash.com/photo-1614850523296-d8c1af93d400?auto=format&fit=crop&q=80&w=800",
  },
  {
    title: "CREATIVE STRATEGY",
    image: "https://images.unsplash.com/photo-1557683316-973673baf926?auto=format&fit=crop&q=80&w=800",
  },
  {
    title: "FUTURE FORWARD",
    image: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80&w=800",
  }
];

export default function HoverReveal() {
  return (
    <section id="about" className="py-40 px-6">
      <div className="max-w-7xl mx-auto">
        <p className="text-brand-accent font-bold uppercase tracking-widest text-xs mb-12">Core Expertise</p>
        <div className="flex flex-col border-t border-white/10">
          {reveals.map((item, idx) => (
            <RevealItem key={idx} item={item} />
          ))}
        </div>
      </div>
    </section>
  );
}

function RevealItem({ item }: { item: typeof reveals[0] }) {
  const [isHovered, setIsHovered] = useState(false);
  
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);

  const springConfig = { damping: 25, stiffness: 150 };
  const sprX = useSpring(mouseX, springConfig);
  const sprY = useSpring(mouseY, springConfig);

  const handleMouseMove = (e: React.MouseEvent) => {
    const rect = e.currentTarget.getBoundingClientRect();
    mouseX.set(e.clientX - rect.left - 150);
    mouseY.set(e.clientY - rect.top - 100);
  };

  return (
    <div 
      className="relative group border-b border-white/10 py-12 md:py-16 overflow-visible cursor-none"
      onMouseMove={handleMouseMove}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="flex items-center justify-between pointer-events-none">
        <h3 className="text-4xl md:text-7xl font-display font-bold tracking-tighter transition-all duration-500 group-hover:translate-x-6 group-hover:text-brand-accent">
          {item.title}
        </h3>
        <span className="text-zinc-600 font-display text-lg hidden md:block">EXPLORE</span>
      </div>

      {/* Floating Image */}
      <motion.div
        style={{
          x: sprX,
          y: sprY,
          opacity: isHovered ? 1 : 0,
          scale: isHovered ? 1 : 0.8,
          rotate: isHovered ? 5 : 0,
        }}
        className="pointer-events-none absolute top-0 left-0 w-[300px] h-[200px] rounded-2xl overflow-hidden z-50 border border-white/20 shadow-2xl"
      >
        <img 
          src={item.image} 
          alt={item.title} 
          className="w-full h-full object-cover"
        />
      </motion.div>
    </div>
  );
}
