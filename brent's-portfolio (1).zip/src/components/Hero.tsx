import { motion } from "motion/react";

export default function Hero() {
  return (
    <section id="home" className="relative min-h-[90vh] flex flex-col items-center justify-start pt-32 px-6 overflow-hidden">
      {/* Background Decorative Elements */}
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-brand-accent/20 rounded-full blur-[140px] -z-10 animate-pulse" />
      <div className="absolute top-1/4 left-1/4 w-[400px] h-[400px] bg-brand-accent-secondary/10 rounded-full blur-[120px] -z-10" />

      {/* Hero Header Area (Small) */}
      <div className="max-w-5xl mx-auto text-center z-10 mb-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        >
          <span className="inline-block px-4 py-1.5 mb-6 rounded-full border border-white/10 bg-white/5 text-xs font-semibold tracking-[0.2em] uppercase">
            BRENT / CREATIVE PORTFOLIO
          </span>
        </motion.div>
      </div>

      {/* 3D asset placeholder - NOW AT THE TOP */}
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.4, duration: 1.2, ease: "easeOut" }}
        className="w-full max-w-7xl h-[500px] md:h-[700px] relative rounded-[3rem] overflow-hidden border border-white/10 glass group shadow-2xl shadow-brand-accent/5"
      >
        <div className="absolute inset-0 bg-gradient-to-b from-white/5 to-transparent flex items-center justify-center">
          <div className="text-center px-10">
            <p className="text-white/20 font-display text-3xl uppercase tracking-[0.3em] mb-4">
              [ 3D ASSET PLACEHOLDER ]
            </p>
            <p className="text-brand-secondary max-w-md mx-auto text-sm">
              Move your interactive asset here to act as the central focal point of the landing experience.
            </p>
          </div>
        </div>
        
        {/* Floating buttons overlaying the asset area */}
        <div className="absolute bottom-12 left-1/2 -translate-x-1/2 flex items-center gap-4 z-20">
           <button className="px-8 py-4 rounded-full bg-white text-black font-bold text-lg hover:bg-zinc-200 transition-all hover:scale-105 active:scale-95 shadow-xl shadow-white/10">
            View Projects
          </button>
          <button className="hidden sm:block px-8 py-4 rounded-full glass font-bold text-lg hover:bg-white/10 transition-all hover:scale-105 active:scale-95">
            Book a Call
          </button>
        </div>

        {/* Decorative mask for transition to next section */}
        <div className="absolute bottom-0 left-0 w-full h-[200px] bg-gradient-to-t from-black to-transparent" />
      </motion.div>
    </section>
  );
}
