import { motion } from "motion/react";
import { Github, Twitter, Instagram, Linkedin } from "lucide-react";

export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="py-20 px-6 border-t border-white/5">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-10">
        <div>
          <h2 className="text-2xl font-display font-bold tracking-tighter mb-4">BRENT</h2>
          <p className="text-brand-secondary text-sm max-w-xs transition-colors hover:text-white">
            Transforming ideas into high-end digital experiences. Based in the future.
          </p>
        </div>

        <div className="flex gap-6">
          <SocialLink href="#" icon={<Github size={20} />} />
          <SocialLink href="#" icon={<Twitter size={20} />} />
          <SocialLink href="#" icon={<Instagram size={20} />} />
          <SocialLink href="#" icon={<Linkedin size={20} />} />
        </div>

        <div className="text-right">
          <p className="text-brand-secondary text-sm mb-2">© {year} Brent Creative Studio.</p>
          <div className="flex gap-4 justify-end">
            <a href="#" className="text-xs text-brand-secondary hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="text-xs text-brand-secondary hover:text-white transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}

function SocialLink({ href, icon }: { href: string; icon: React.ReactNode }) {
  return (
    <motion.a
      href={href}
      whileHover={{ y: -5, scale: 1.1 }}
      className="w-10 h-10 rounded-full border border-white/10 flex items-center justify-center text-brand-secondary hover:text-white hover:border-white transition-colors"
    >
      {icon}
    </motion.a>
  );
}
