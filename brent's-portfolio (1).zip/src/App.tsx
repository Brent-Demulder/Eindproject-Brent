/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import Projects from "./components/Projects";
import ValueProp from "./components/ValueProp";
import LogoMarquee from "./components/LogoMarquee";
import HoverReveal from "./components/HoverReveal";
import Footer from "./components/Footer";

export default function App() {
  return (
    <main className="min-h-screen">
      <Navbar />
      <Hero />
      <LogoMarquee />
      <Projects />
      <HoverReveal />
      <Footer />
    </main>
  );
}
